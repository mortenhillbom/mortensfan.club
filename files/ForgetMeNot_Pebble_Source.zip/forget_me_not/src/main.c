#include <pebble.h>

static Window *s_main_window;
static TextLayer *s_time_layer;
static GFont s_time_font;
static BitmapLayer *s_background_layer;
static GBitmap *s_background_bitmap;

static TextLayer *s_acc_layer;
static GFont bebas;

static DictationSession *s_dictation_session;
static char s_last_text[512];




// SENDING STUFFFFFF
// Key values for AppMessage Dictionary
enum {
	STATUS_KEY = 0,	
	MESSAGE_KEY = 1
};

// Write message to buffer & send
void send_message(char *message){
	DictionaryIterator *iter;
	
	app_message_outbox_begin(&iter);
	dict_write_cstring(iter, MESSAGE_KEY, message);
	
	dict_write_end(iter);
  	app_message_outbox_send();
}

// Called when a message is received from PebbleKitJS
static void in_received_handler(DictionaryIterator *received, void *context) {
	Tuple *tuple;
	
	tuple = dict_find(received, STATUS_KEY);
	if(tuple) {
		APP_LOG(APP_LOG_LEVEL_DEBUG, "Received Status: %d", (int)tuple->value->uint32); 
	}
	
	tuple = dict_find(received, MESSAGE_KEY);
	if(tuple) {
		APP_LOG(APP_LOG_LEVEL_DEBUG, "Received Message: %s", tuple->value->cstring);
	}}

// Called when an incoming message from PebbleKitJS is dropped
static void in_dropped_handler(AppMessageResult reason, void *context) {	
}

// Called when PebbleKitJS does not acknowledge receipt of a message
static void out_failed_handler(DictionaryIterator *failed, AppMessageResult reason, void *context) {
}



static void dictation_session_callback(DictationSession *session, 
													DictationSessionStatus status, 
													char *transcription, void *context){
	//Print the results of a trancsription attempt
	APP_LOG(APP_LOG_LEVEL_INFO, "Dictation status: %d", (int)status);
	
	if(status == DictationSessionStatusSuccess){
		snprintf(s_last_text, sizeof(s_last_text), "%s", transcription);
		
	
		send_message(s_last_text);
			
			
		text_layer_set_text(s_acc_layer, s_last_text);
	}else{
		static char s_failed_buff[128];
		snprintf(s_failed_buff, sizeof(s_failed_buff), "Transcription failed.\n\nBecause:\n%d", (int)status);
		text_layer_set_text(s_acc_layer, s_failed_buff);
	}
}


static void update_time(){
  //Get a tttttmmm structure
	time_t temp = time(NULL);
	struct tm *tick_time = localtime(&temp);
	
  //Erry day I'm buffering the current hours and minutes
	static char s_buffer[8];
	strftime(s_buffer, sizeof(s_buffer), clock_is_24h_style() ?
		"%H:%M" : "%I:%M", tick_time);
	
  //Display it at the textLayer
	text_layer_set_text(s_time_layer, s_buffer);
}

static void tick_handler(struct tm *tick_time, TimeUnits units_changed){
	update_time();
}

static void tap_handler(AccelAxisType axis, int32_t direction){
  //HFHFHFHHF
	switch(axis){
    //The one we care about for handshaking
		case ACCEL_AXIS_X:
		if(direction > 0){
			text_layer_set_text(s_acc_layer, "");
		}else{
			text_layer_set_text(s_acc_layer, "");
		}
		break;
		case ACCEL_AXIS_Y:
		if(direction > 0){
			//text_layer_set_text(s_acc_layer, "Y axis positive");
			
			dictation_session_start(s_dictation_session);
			
		}else{
		//	text_layer_set_text(s_acc_layer, "Y axis negative");
			dictation_session_start(s_dictation_session);

		}
		break;
		case ACCEL_AXIS_Z:
		if(direction > 0){
			text_layer_set_text(s_acc_layer, "");
		}else{
			text_layer_set_text(s_acc_layer, "");
		}
		break;
		
	}
	
}

static void main_window_load(Window *window){
	
	//Create FOOOONT
	s_time_font = fonts_load_custom_font(resource_get_handle(RESOURCE_ID_FONT_KEY_ROBOTO_42));
	bebas = fonts_load_custom_font(resource_get_handle(RESOURCE_ID_FONT_BEBAS_NEUE_22));

	//Create window dude, by getting da information and copy
	Layer *window_layer = window_get_root_layer(window);
	GRect bounds = layer_get_bounds(window_layer);
	
	s_background_bitmap = gbitmap_create_with_resource(RESOURCE_ID_BACKGROUND_IMAGE);
	s_background_layer = bitmap_layer_create(bounds);
	bitmap_layer_set_bitmap(s_background_layer, s_background_bitmap);
	layer_add_child(window_layer, bitmap_layer_get_layer(s_background_layer));
	
  //Create textLayer accordingly
	s_time_layer = text_layer_create(
		GRect(0, PBL_IF_ROUND_ELSE(58, 52), bounds.size.w, 50));
		
	
  //Make swag
	text_layer_set_background_color(s_time_layer, GColorClear);
	text_layer_set_text_color(s_time_layer, GColorWhite);
	text_layer_set_font(s_time_layer, s_time_font);
	text_layer_set_text_alignment(s_time_layer, GTextAlignmentCenter);
	
  //Add as child to window's root layer
	layer_add_child(window_layer, text_layer_get_layer(s_time_layer));
	
	s_acc_layer = text_layer_create(
		GRect(10, PBL_IF_ROUND_ELSE(118, 112), bounds.size.w, 50)
	);
	
	text_layer_set_background_color(s_acc_layer, GColorClear);
	text_layer_set_text_color(s_acc_layer, GColorWhite);
	text_layer_set_font(s_acc_layer, bebas);
	text_layer_set_text_alignment(s_acc_layer, GTextAlignmentLeft);
	
	layer_add_child(window_layer, text_layer_get_layer(s_acc_layer));
	
	s_dictation_session = dictation_session_create(sizeof(s_last_text),
																  dictation_session_callback, NULL);
	dictation_session_enable_error_dialogs(s_dictation_session, false);
		

}

static void main_window_unload(Window *window){
  //Kill da window
	text_layer_destroy(s_time_layer);
	fonts_unload_custom_font(s_time_font);
	gbitmap_destroy(s_background_bitmap);
	bitmap_layer_destroy(s_background_layer);
	text_layer_destroy(s_acc_layer);
	
}

static void init(){
  //Creating da window
	s_main_window = window_create();
	
  //Handers are nice
	window_set_window_handlers(s_main_window, (WindowHandlers){
		.load = main_window_load,
		.unload = main_window_unload
	});
	
	window_set_background_color(s_main_window, GColorBlack);
	
  //Showing da window with animation = true
	window_stack_push(s_main_window, true);
	
	update_time();
	

  //Make sure da tickhandler get dem minutes (not seconds)
	tick_timer_service_subscribe(MINUTE_UNIT, tick_handler);
	
  //Subscribe to accelorometer
	accel_tap_service_subscribe(tap_handler);
	accel_service_set_sampling_rate(69);
	
	app_message_register_inbox_received(in_received_handler); 
	app_message_register_inbox_dropped(in_dropped_handler); 
	app_message_register_outbox_failed(out_failed_handler);
		
	app_message_open(app_message_inbox_size_maximum(), app_message_outbox_size_maximum());
	
	
}

static void deinit(){
  //I say, ey, kill da shit outta this window
	window_destroy(s_main_window);
	
  //Unsubscribe to accelorermetmetr
	accel_tap_service_unsubscribe();

}

int main(void){
	init();
	app_event_loop();
	deinit();
}