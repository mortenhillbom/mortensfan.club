package com.mortenerpen.mortensfan.club.mortensfanclub;

import android.app.Activity;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.getpebble.android.kit.Constants;
import com.getpebble.android.kit.PebbleKit;
import com.getpebble.android.kit.util.PebbleDictionary;

import java.util.ArrayList;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.UUID;

import android.content.Context;


public class people_list extends Activity {

    private static final int STATUS_KEY = 0;
    private static final int MESSAGE_KEY = 1;

    private ListView people_list;
    private ArrayList<String> people;
    private ArrayAdapter<String> personAdapter;

    private PebbleKit.PebbleDataReceiver mReceiver;
    private UUID handshakeApp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_people_list);
        setUpView();
    }

    private void setUpView(){

        // Launch the sports app
        Context context = getApplicationContext();
        handshakeApp = UUID.fromString("6b5dea32-2b13-44bc-8946-233d5d09e9dc");

        boolean isConnected = PebbleKit.isWatchConnected(context);

        if(isConnected) {
            // Launch the sports app

            PebbleKit.startAppOnPebble(context, handshakeApp);

            Toast.makeText(context, "Launching...", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Watch is not connected!", Toast.LENGTH_LONG).show();
        }
        people_list = (ListView) findViewById(R.id.people_list);
        people = new ArrayList<String>();
        people.clear();

       // personAdapter = new ArrayAdapter<String>(this, (TextView)android.R.layout.simple_list_item_2, people);
        personAdapter = new ArrayAdapter<String>(context, android.R.layout.simple_list_item_1, people);
        people_list.setAdapter(personAdapter);

        addItemList("Name, Day, date, time");
    }

    public void addItemList(String dude){
        people.add(dude);
        personAdapter.notifyDataSetChanged();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_people_list, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Construct output String
        StringBuilder builder = new StringBuilder();
        builder.append("Pebble ");

        // Is the watch connected?
        boolean isConnected = PebbleKit.isWatchConnected(this);
        builder.append("connected: " + (isConnected ? "true" : "false")).append("\n");

        // Is AppMesage supported?
        boolean appMessageSupported = PebbleKit.areAppMessagesSupported(this);
        builder.append("AppMessage supported: " + (appMessageSupported ? "true" : "false"));

        TextView status_text = (TextView)findViewById(R.id.status_text);
        status_text.setText(builder.toString());


        if(mReceiver == null) {
            mReceiver = new PebbleKit.PebbleDataReceiver(handshakeApp) {

                @Override
                public void receiveData(Context context, int id, PebbleDictionary data) {
                    //Always acknowledge to prevent timeouts
                    PebbleKit.sendAckToPebble(context, id);

                    //get action and display
                    Log.i("receiveData", "Got message from Pebble!");

                    addPerson(data.getString(MESSAGE_KEY));

                }

            };

            System.out.println(PebbleKit.registerReceivedDataHandler(getApplicationContext(), mReceiver).toString());

        }
    }

    public void addPerson(String sentence){
        String name = extractName(sentence);
       // Person dude = new Person(name);
        addItemList(name);
    }

    public String extractName(String s){
        //OK, I admit it, this "algorithm" for extracting name is super ghetto! But it kinda works, so who cares
        //And no, noone other than me is allowed to be named Martin, Morgan or Morton according to this
        String[] notNames = {"hi","hello","martin","morgan","mark","my","name","is","i","am","i'm","what","what's","up","hey","morton"};
        String[] words = s.split(" ");
        String returnString = "";

        for(int i = 0; i < words.length; i++){
            if(Arrays.asList(notNames).contains(words[i].toLowerCase())){
                words[i] = "";
            }
        }

        for(int i = 0; i < words.length; i++){
            if(!words[i].equalsIgnoreCase("")) {
                returnString = returnString + " " + words[i];
            }
        }

        DateFormat df = new SimpleDateFormat("EEE, d MMM yyyy, HH:mm");
        String date = ", " + df.format(Calendar.getInstance().getTime());

        if(returnString.equals("")){
            returnString = "Sorry, didn't understand";
        }
        return returnString + date;
    }
}


